// Group with Martin, Elias, Nicklas, Philip

public class Main {
    public static void main(String[] args) {
        MenuCard menucard = new MenuCard();
        Console console = new Console(menucard);

        console.startConsole();
    }
}

